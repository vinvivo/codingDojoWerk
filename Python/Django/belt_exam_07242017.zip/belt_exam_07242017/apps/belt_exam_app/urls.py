from django.conf.urls import url
from django.conf import settings
from django.contrib.auth.views import logout
from . import views

urlpatterns = [
    url(r'^$', views.main),
    url(r'^main$', views.index),  # login page
    url(r'login$', views.log_in),  # login verifies and redirects to succes
    url(r'users$', views.register),  # register verifies and redirects to success
    url(r'success$', views.success),  # success redirects to landing page (here, quotes)
    url(r'travels$', views.travels),  # renders landing page
    url(r'destination/(?P<id>\d+)$', views.destination), # user details
    url(r'post_trip$', views.post_trip),  # posts to site
    url(r'join/(?P<id>\d+)$', views.join),  # adds trip to trips_list
    url(r'signout$', logout, {'next_page': '/main'}, name='logout')  # logout user
]